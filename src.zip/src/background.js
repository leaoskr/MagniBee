chrome.runtime.onInstalled.addListener(()=>{
    console.log("installed");
}
)